from django.contrib import admin
from employees.models import Employee_records

admin.site.register(Employee_records)
